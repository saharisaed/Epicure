import IChefs from "./IChefs";

type chef={
    chef:IChefs;
}


export default chef;