import res from "../restaurantsTypes/restaurants";

export interface IChefs{
    name:string;
    definition:string;
    img:string;
}

export default IChefs