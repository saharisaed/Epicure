import IRestaurants from "./IRestaurants";



type res={
    restaurant:IRestaurants;
}


export default res;