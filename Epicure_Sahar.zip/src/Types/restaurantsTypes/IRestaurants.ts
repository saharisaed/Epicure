interface IRestaurants{
    name:string;
    chef:string;
    img:string;
}

export default IRestaurants;