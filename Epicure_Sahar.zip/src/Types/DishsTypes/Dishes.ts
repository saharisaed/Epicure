import IDishs from "./IDishs";

type dish={
    dish:IDishs;
}


export default dish;