interface IDishs{
    name:string;
    ingredients:string;
    img:string;
    icon:string;
    price:number;
    ILSIcon:string;
}

export default IDishs;