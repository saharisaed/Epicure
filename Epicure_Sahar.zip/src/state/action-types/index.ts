export enum ActionType {
    FILTER="filter",
    SEARCH="search",
}
