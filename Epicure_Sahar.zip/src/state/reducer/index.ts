import { combineReducers } from "redux";
import restaurantsReducer from "../reducer/filterRestaurants"
import searchReducer from "../reducer/searchSlider"

const reducers = combineReducers({
    filter:restaurantsReducer,
    search:searchReducer,

})

export default reducers;

export type State = ReturnType<typeof reducers>