import {Action} from "../../state/actions/index"
import { ActionType } from "../action-types";
const initialState ="All";

const reducer =(state:string=initialState ,action:Action) => {
  switch(action.type){
    case ActionType.FILTER :
      return action.payload;

    default:
      return state
  }

}

export default reducer;




