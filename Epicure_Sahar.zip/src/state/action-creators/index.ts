import { ActionType } from "../action-types"
import { Dispatch } from "redux"
import {Action, ActionSearch} from "../../state/actions/index"

const filterRestaurant =(filterName:string)=>{
    return (dispatch:Dispatch<Action>) => {
        dispatch({
            type:ActionType.FILTER,
            payload:filterName
        })
    }
}


const filterDishes =(filterName:string)=>{
    return (dispatch:Dispatch<Action>) => {
        dispatch({
            type:ActionType.FILTER,
            payload:filterName
        })
    }
}

const filterSearch =(filterName:string)=>{
    return (dispatch:Dispatch<ActionSearch>) => {
        dispatch({
            type:ActionType.SEARCH,
            payload:filterName
        })
    }
}
 


export  {filterRestaurant,filterDishes,filterSearch};