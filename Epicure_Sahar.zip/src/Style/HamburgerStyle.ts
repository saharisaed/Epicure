import { NavLink } from "react-router-dom";
import styled from "styled-components";

export const HambStyle=styled.div`
                            display: flex;
                            overflow: hidden`

export const MenuIcon=styled.div`
                            padding-left: 7%;`

                            
export const ShowMenuIcon=styled.div`
                        visibility: visible;`

export const HideMenuIcon=styled.div`
                        visibility: hidden;`

export const CloseIcon=styled.div`
                        visibility: visible;
                        display: flex;
                        position: relative;
                        right: 38%;
                        top: 10%;`

export const Hambelements=styled.div`
                        position: absolute;
                        justify-content: flex-start;
                        left: 0; 
                        top: 60px;
                        background-color: #ffffff;
                        width: 0px;
                        height: calc(100vh - 60px);
                        visibility: visible;
                        display: flex;
                        flex-direction: column;
                        align-items: flex-start;
                        gap: 24px;
                        position: absolute;
                        width: 105%;
                        height: 367px;
                        flex: content;
                        left: -1px;
                        top: 46px;
                        background: #FFFFFF;
                        box-shadow: 2px 4px 10px rgba(175, 175, 175, 0.25);
                        overflow:hidden`

export const HambelementsText=styled.ul`
                        justify-content: start;
                        display: flex;
                        font:  Helvetica Neue;
                        flex-direction: column;
                        display: flex;
                        justify-content: space-between;
                        list-style-type: none;`   
                        
export const HambElement=styled.li`
                        justify-content: start;
                        font-family: 'Helvetica Neue';
                        font-style: normal;
                        font-weight: 200;
                        font-size: 18px;
                        line-height: 22px;
                        letter-spacing: 1.92px;
                        color: #000000;
                        flex: none;
                        order: 0;
                        flex-grow: 0;
                        top: 22px;
                        overflow:hidden;`

export const HambElementLink=styled(NavLink)`
                        font-size: 16px;
                        font-weight: 400;
                        color: #2f234f;
                        text-decoration: none;
                        color: #574c4c;
                        font-weight: 500;
                        position: relative;
                        visibility: visible;
                        overflow:hidden;`