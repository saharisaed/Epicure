import styled from "styled-components";

export const Signaturediv=styled.div`
                            display: flex;
                            flex-direction: column;
                            justify-content: center;
                            align-items: center;
                            gap: 32px;
                            width: 100%;
                            height: 610px;
                            background: #FAFAFA;`

export const Title=styled.h1`
                            font-family: 'Helvetica Neue';
                            font-style: normal;
                            font-weight: 200;
                            font-size: 18px;
                            line-height: 35px;
                            padding-top: 24px;
                            letter-spacing: 1.25px;
                            text-transform: uppercase;
                            color: #000000;`

export const DishType=styled.h2`
                            font-family: 'Helvetica Neue';
                            font-style: normal;
                            font-weight: 200;
                            font-size: 18px;
                            line-height: 30px;
                            text-align: center;
                            letter-spacing: 1.97px;
                            color: #000000;`

