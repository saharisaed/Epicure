import styled from "styled-components";

export const CartStyle=styled.div`
                            height: 46px;
                            display: flex;
                            background-color: #ffffff;
                            /* position: relative; */
                            padding-top: 12%;
                            align-content: center;
                            flex-direction: column;
                            justify-content: center;
                            align-items: center;`

export const Cartimg=styled.img`
                            padding-top: 95%;`

export const Cartcontent=styled.h1`
                            font-family: 'Helvetica Neue';
                            font-style: normal;
                            font-weight: 200;
                            font-size: 16px;
                            line-height: 20px;
                            text-align: center;
                            letter-spacing: 1.97px;
                            text-transform: uppercase;
                            color: #000000;
                            flex: none;
                            order: 0;
                            flex-grow: 0;
                            top: 22px;
                            display: flex;
                            flex-direction: column;
                            justify-content: flex-start;
                            align-items: center;
                            padding: 0px;
                            gap: 20px;
                            width: 263%;
                            height: 150%;`
                        
export const Cartassest=styled.div``

export const Carticon=styled.div``

export const Cartelement=styled.div`
                            visibility: visible;
                            display: flex;
                            position: fixed;
                            z-index: 2;
                            flex-direction: column;
                            gap: 24px;
                            left: 0px;
                            width: 100%;
                            height: 218px;
                            background: #FFFFFF;
                            box-shadow: 2px 4px 10px rgb(175 175 175 / 25%);
                            align-content: center;
                            align-items: center;
                            justify-content: space-between;
                            overflow:hidden`