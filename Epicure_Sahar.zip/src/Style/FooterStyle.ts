import { NavLink } from "react-router-dom";
import styled from "styled-components";

export const FooterStyle=styled.div`
                            display: flex;
                            flex-direction: column;
                            gap: 32px;
                            width: auto;
                            padding-top: 20px;
                            background: #FAFAFA;
                            padding-left: 20px;`

export const Footerimg=styled.img`
                            display: flex;
                            justify-content: flex-start;
                            width: fit-content;`

export const Footertitle=styled.div`
                            font-family: 'Helvetica Neue';
                            font-style: normal;
                            font-weight: 200;
                            font-size: 18px;
                            line-height: 35px;
                            letter-spacing: 1.25px;
                            text-transform: uppercase;
                            color: #000000;`

export const Footercontent=styled.div`
                            font-family: 'Helvetica Neue';
                            font-style: normal;
                            font-weight: 200;
                            font-size: 18px;
                            line-height: 28px;
                            letter-spacing: 2.14px;
                            color: #000000;`


export const Mutalfooter=styled.ul`
                            display: flex;
                            flex-direction: column;
                            align-items: flex-start;
                            gap: 24px;
                            flex: content;
                            background: #FFFFFF;
                            padding-inline-start: 0px;
                            padding-left: 20px;
                            padding-top: 15px;`


export const MutalfooterLink=styled(NavLink)`
                            font-family: 'Helvetica Neue';
                            font-style: normal;
                            font-weight: 200;
                            font-size: 18px;
                            line-height: 22px;
                            letter-spacing: 1.92px;
                            color: #000000;
                            text-decoration: none;`