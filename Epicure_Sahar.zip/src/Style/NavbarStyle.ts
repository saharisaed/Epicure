import { NavLink } from "react-router-dom";
import styled from "styled-components";

export const NavbarStyle=styled.div`
                                top: 0;
                                background-color: #ffffff;
                                justify-content: space-between;
                                height: 46px;
                                display: flex;
                                flex-direction: row;
                                width: 100%;
                                position: sticky;
                                align-items: center;
                                z-index: 1;`

export const Logo=styled.div`
                                display: flex;
                                justify-content: center;
                                padding-left: 15%;
                                overflow:hidden`

export const HomeLink=styled(NavLink)``

export const Icon=styled.div``

export const Navbarelements=styled.div`
                                display: flex;
                                gap: 5px;
                                margin-inline-start: 0px;
                                flex-direction: row;
                                justify-content: center;
                                align-content: center;`