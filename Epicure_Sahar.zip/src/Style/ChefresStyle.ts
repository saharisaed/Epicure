import styled from "styled-components";

export const ChefRestaurantsContainer=styled.div`
                                width: 100%;`

export const ChefRestaurantsContainerTxt=styled.i`
                                padding-left: 20px;
                                font-family: 'Helvetica Neue';
                                font-style: normal;
                                font-weight: 200;
                                font-size: 18px;
                                line-height: 35px;
                                letter-spacing: 1.25px;
                                text-transform: uppercase;
                                color: #000000;`

export const ChefRestaurants=styled.div`
                                display: flex;
                                flex-direction: row;
                                align-items: flex-start;
                                padding: 0px;
                                gap: 24px;
                                width: auto;
                                height: 20%;
                                overflow-x: scroll;
                                font-family: 'Helvetica Neue';
                                padding-left: 20px;
                                padding-top: 15px;`