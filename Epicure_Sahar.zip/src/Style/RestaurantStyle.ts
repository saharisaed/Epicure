import styled from "styled-components";


export const Cardchef=styled.div``
export const RestaurantContainer=styled.div`
                                width: 100%;`

export const RestContainerText=styled.i`
                                align-content: baseline;
                                height: 24px;
                                padding-left: 20px;
                                font-family: 'Helvetica Neue';
                                font-style: normal;
                                font-weight: 200;
                                font-size: 18px;
                                line-height: 24px;
                                letter-spacing: 1.25px;
                                text-transform: uppercase;
                                color: #000000;`

export const Restaurants=styled.div`
                                display: flex;
                                flex-direction: row;
                                flex-wrap: nowrap;
                                align-items: flex-start;
                                padding: 0px;
                                gap: 24px;
                                width: auto; 
                                padding-left: 20px;
                                padding-top: 15px;
                                height: 25%;
                                overflow-x: scroll;`
                        

