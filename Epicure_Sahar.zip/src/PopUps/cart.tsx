import { Cartcontent, Cartimg, CartStyle } from "../Style/CartStyle";

const Cart= () =>{
  
    return(
    
            <CartStyle> 
        
            <Cartimg src={require('../Media/Icons/cart_icon2.png')} />

             <Cartcontent>Your bag is<br></br> empty</Cartcontent>
            
            </CartStyle>
                
             
          
        

    )
}

export default Cart;