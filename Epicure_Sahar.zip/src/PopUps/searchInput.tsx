import { SearchPopup, SearchText, SearchTextElemnt } from "../Style/SearchStyle";
import restaurantSearch from '../Data/restaurantsByName.json';
import DishesSearch from '../Data/DishsByName.json';
import { Provider, useSelector } from "react-redux";
import { State, store } from "../state";
import { useEffect, useState } from "react";

export interface ListByName{
    name:string;
}

const SearchInputPopup= () =>{
    const searchInput =useSelector((state :State) => state.search)
    const search =useSelector((state :State) => state.search)
    const [dishSuggistion,setDishSuggistion] =useState<string|undefined>("");
    const [RestaurantSuggistion,setRestaurantSuggistion] =useState<string|undefined>();
    
    useEffect(() => {
        
        const GetSearchingSuggestion=()=>{
            const restaurantListFilterd=restaurantSearch.restaurantSearch.filter((elemnt:ListByName)  => elemnt.name.toLowerCase().includes(searchInput)).shift();
            restaurantListFilterd? setRestaurantSuggistion(restaurantListFilterd.name):setRestaurantSuggistion("");
            const dishesListFilterd=DishesSearch.DishesSearch.filter((elemnt:ListByName)  =>  elemnt.name.toLowerCase().includes(searchInput)).shift();
            dishesListFilterd? setDishSuggistion(dishesListFilterd.name):setDishSuggistion("");   
        }
        GetSearchingSuggestion();
      },[searchInput]);

        return(
            <SearchPopup id="searchInput">
                <SearchText>Restaurants:</SearchText>
                <SearchTextElemnt>{RestaurantSuggistion}</SearchTextElemnt>
                <SearchText>Cusine:</SearchText>
                <SearchTextElemnt>{dishSuggistion}</SearchTextElemnt>
            </SearchPopup>
        )
}



export default SearchInputPopup;

