import { BrowserRouter, Route, Routes } from 'react-router-dom'
import MutalFooter from './components/MutalFooter'
import Navbar from './components/Navbar'
import Home from './pages/Home'
import Restaurants from './pages/Restaurants'


const App = () => {
  return (
    <BrowserRouter>
     <Navbar />
      <Routes>
        <Route key={1}  index path="/" element={<Home />} /> 
        <Route key={2} path="/Restaurants/"  element={<Restaurants />} />
      </Routes>
      <MutalFooter/>
    </BrowserRouter>
  )
}

export default App