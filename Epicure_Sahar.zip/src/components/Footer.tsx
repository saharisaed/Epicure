import { NavLink } from "react-router-dom";
import { Footercontent, Footerimg, FooterStyle, Footertitle } from "../Style/FooterStyle";
import MutalFooter from "./MutalFooter";



const Footer=()=>{
    return(
        <FooterStyle>
            <Footerimg src={('../Media/logo.svg')} /> 
            <Footerimg src={('../Media/googleplay.svg')} /> 
            <Footerimg src={('../Media/appstore.svg')} /> 
            <Footertitle>about us:</Footertitle>
            <Footercontent>Lorem ipsum dolor sit amet, consectetur adipiscing elit. In a lacus vel justo fermentum bibendum non 
                eu ipsum. Cras porta malesuada eros, eget blandit
                turpis suscipit at.  Vestibulum sed massa in magna sodales porta.  Vivamus elit urna, 
                dignissim a vestibulum.
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. In a lacus vel justo fermentum bibendum no
                eu ipsum. Cras porta malesuada eros.
            </Footercontent>
        </FooterStyle>

    );

}


export default Footer;