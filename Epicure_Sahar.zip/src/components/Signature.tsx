import { DishType, Signaturediv, Title } from "../Style/SignatureStyle";


const Signature=()=>{

    return(
        <Signaturediv>
            <Title>Signature Dish Of:</Title>
            <img src={('./Media/icons/spicy_icon2.svg')} />
            <DishType>Spicy</DishType>
            <img src={('./Media/icons/vegitarian_icon.svg')} />
            <DishType>Vegitarian</DishType>
            <img src={('./Media/icons/vegan_icon.svg')} />
            <DishType>Vegan</DishType>
        </Signaturediv>
    )

}

export default Signature; 