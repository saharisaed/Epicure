import res from '../Types/restaurantsTypes/restaurants';

const RestaurantsPageCard:React.FC<res> = ({ 
    restaurant
})=>{
    return (
      <div className="card-wrapper">
        <div className='card-img'>
          <img src={restaurant.img} />
        </div>
        <div className='card-content'>
          <h3>{restaurant.name}</h3>
          <div>{restaurant.chef}</div>
        </div>
        </div>
    );
}


export default RestaurantsPageCard;