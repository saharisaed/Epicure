import {  Cardcontent, Cardimg, Cardwrapper,Name } from '../../Style/CardStyle';
import {Cardchef} from '../../Style/RestaurantStyle';
import res from '../../Types/restaurantsTypes/restaurants';

const RestaurantsCard:React.FC<res> = ({ 
    restaurant
})=>{
    return (
      <Cardwrapper>
        <Cardimg>
          <img src={restaurant.img} />
        </Cardimg>
        <Cardcontent>
          <Name>{restaurant.name}</Name>
          <Cardchef>{restaurant.chef}</Cardchef>
        </Cardcontent>
        </Cardwrapper>
    );
}






export default RestaurantsCard;