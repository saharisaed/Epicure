import restaurantList from '../../Data/restaurants.json'
import { All } from '../../Style/CardStyle';
import { RestaurantContainer, Restaurants, RestContainerText } from '../../Style/RestaurantStyle';
import IRestaurants from '../../Types/restaurantsTypes/IRestaurants';
import RestaurantsCard from './RestaurantsCard';

const RestContainer=() =>{
    return(
            <RestaurantContainer>
                <RestContainerText>
                    popular restaurant in epicure:
                </RestContainerText>
            
            <Restaurants>
                {
                    restaurantList.restaurant.map((restaurant:IRestaurants, index)=><RestaurantsCard restaurant={restaurant} key={index}/>)
                }
            </Restaurants>
            <All to={'Restaurants'}>All restaurants<img src={require('../../Media/Icons/allres_icon.png')} /></All>
            </RestaurantContainer>
    )
}


export default RestContainer;