import { NavLink } from 'react-router-dom';
import restaurantList from '../Data/restaurants.json'
import IRestaurants from '../Types/restaurantsTypes/IRestaurants';
import RestaurantsCard from './RestaurantsInHome/RestaurantsCard';

const RestPageContainer=() =>{
    return(
        <div className='RestPageContainerText'>
            <i>
                Restaurants
            </i>
        <div className="RestPageContainer">
            {
                restaurantList.restaurant.map((restaurant:IRestaurants, index)=><RestaurantsCard restaurant={restaurant} key={index}/>)
            }
        </div>
        </div>
    )
}


export default RestPageContainer;