import { ReactComponent as Brand } from '../Media/logo.svg'
import NavbarAssest from '../assest/NavbarAssest'
import Hambassest from '../assest/Hambassest'
import SearchICN from '../Media/Search_logo.svg'
import { NavLink } from 'react-router-dom'
import { HomeLink, Logo, NavbarStyle } from '../Style/NavbarStyle'

const Navbar = () => {
  
 
  return (
    <NavbarStyle id='Navbar'>
          <Hambassest/>
    
        <Logo> 
          {
           <HomeLink to={"Home"}> <Brand /> </HomeLink>
          }
        </Logo>

          <NavbarAssest/>
     
    </NavbarStyle>
  )
}

export default Navbar