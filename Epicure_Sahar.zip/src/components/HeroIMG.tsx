import img from '../Media/Heroimg.svg'
import Search from '../PopUps/search';
import SearchInput from '../PopUps/searchInput';
import { Heroimage, HeroTxt } from '../Style/HomeStyle'

const Heroimg=() =>{
    return (
        <Heroimage >
            <HeroTxt>
                Epicure works with the top
                chef restaurants in Tel Aviv
                <Search/>
            </HeroTxt>
        </Heroimage>
    );
}

export default Heroimg;