import chefList from '../../Data/chefs.json'
import { ChefContainerdiv, ChefContainerText, Chefs } from '../../Style/ChefStyle';
import IChefs from '../../Types/chefType/IChefs';
import IRestaurants from '../../Types/restaurantsTypes/IRestaurants';
import ChefCard from './chefCard';


   
const ChefContainer=() =>{
    return(
        <ChefContainerdiv>
            <ChefContainerText>
                  Chef of the week:
            </ChefContainerText>
        <Chefs>
            {
                chefList.chef.map((chef:IChefs, index)=><ChefCard chef={chef} key={index}/>)
            }
      
        </Chefs>
        </ChefContainerdiv>
 
    )
}


export default ChefContainer;