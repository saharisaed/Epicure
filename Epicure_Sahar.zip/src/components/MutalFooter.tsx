import { NavLink } from "react-router-dom"
import { Mutalfooter, MutalfooterLink } from "../Style/FooterStyle"

const MutalFooter=()=>{
    return(
        <Mutalfooter>
           <MutalfooterLink to="/projects">Contact Us</MutalfooterLink> 
           <MutalfooterLink to="/about">Term of Use</MutalfooterLink>  
           <MutalfooterLink to="/contact">Privacy Policy</MutalfooterLink> 
        </Mutalfooter>
    )
}

export default MutalFooter