import { NavLink } from 'react-router-dom'
import { HambElement, HambElementLink, HambelementsText } from '../Style/HamburgerStyle';

const Hamburger=() =>{

  const handleHideHamb=()=>{
      let a=document.getElementById('NavbarAssest');
      let b=document.getElementById('HambelementsText');
      if(a) a.style.visibility='hidden';
      if(b) b.style.visibility='hidden';

  }
  
    return (
        <HambelementsText id='HambelementsText'> 
            <HambElement>
              <HambElementLink to="/Restaurants" onClick={handleHideHamb}>Restaurants</HambElementLink>
            </HambElement>
            <HambElement>
              <HambElementLink to="/Chefs">Chefs</HambElementLink>
            </HambElement>
            <br></br>
            <HambElement>
              <HambElementLink to="/projects">Contact Us</HambElementLink>
            </HambElement>
            <HambElement>
              <HambElementLink to="/about">Term of Use</HambElementLink>
            </HambElement>
            <HambElement>
              <HambElementLink to="/contact">Privacy Policy</HambElementLink>
            </HambElement>
          </HambelementsText>
    );

}

export default Hamburger;