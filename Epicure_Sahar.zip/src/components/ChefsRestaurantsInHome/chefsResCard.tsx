import { Cardcontent, Cardimg, Cardwrapper, Name } from '../../Style/CardStyle';
import res from '../../Types/restaurantsTypes/restaurants';

const ChefRestaurantsCard:React.FC<res> = ({ 
    restaurant
})=>{

      return (
      <Cardwrapper>
        <Cardimg>
          <img src={restaurant.img} />
        </Cardimg>
        <Cardcontent>
          <Name>{restaurant.name}</Name>
        </Cardcontent>
        </Cardwrapper>
    );
}



export default ChefRestaurantsCard;