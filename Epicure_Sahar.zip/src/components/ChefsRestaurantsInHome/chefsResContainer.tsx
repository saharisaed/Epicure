import { NavLink } from 'react-router-dom';
import restaurantList from '../../Data/restaurants.json'
import { All } from '../../Style/CardStyle';
import { ChefRestaurants, ChefRestaurantsContainer, ChefRestaurantsContainerTxt } from '../../Style/ChefresStyle';
import IRestaurants from '../../Types/restaurantsTypes/IRestaurants';
import res from '../../Types/restaurantsTypes/restaurants';
import ChefRestaurantsCard from './chefsResCard';

const ChefResContainer=() =>{
    let restaurants:IRestaurants[] = restaurantList.restaurant.filter( function (restaurant) {
          return restaurant.chef === "Yossi Shitrit"
    });

        return (
            <ChefRestaurantsContainer>
              <ChefRestaurantsContainerTxt>
                    Chef of the week:
              </ChefRestaurantsContainerTxt>
            <ChefRestaurants>
            {
                restaurants.map((restaurant:IRestaurants, index)=><ChefRestaurantsCard restaurant={restaurant} key={index}/>)
            }
            </ChefRestaurants>
                 <All to="Restaurants">All restaurants<img src={require('../../Media/Icons/allres_icon.png')} /></All>
            </ChefRestaurantsContainer>
          );
}


export default ChefResContainer;