import { Cardcontent, Cardimg, Cardwrapper, Name } from '../../Style/CardStyle';
import { DishIcon, Ingredients, Price, Priceimg} from '../../Style/DishsStyle';
import dish from '../../Types/DishsTypes/Dishes';

const DishsCard:React.FC<dish> = ({ 
    dish
})=>{
    return (
      <Cardwrapper>
        <Cardimg>
          <img src={dish.img} />
        </Cardimg>
        <Cardcontent>
          <Name>{dish.name}</Name>
          <Ingredients>{dish.ingredients}</Ingredients>
          <DishIcon> <img src={dish.icon} /></DishIcon>
          <Price>{<Priceimg src={dish.ILSIcon}/>}{dish.price}</Price>
        </Cardcontent>
        </Cardwrapper>
    );
}






export default DishsCard;