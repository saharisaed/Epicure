import DishContainer from '../components/DishsInHome/DishContainer'
import Heroimg from '../components/HeroIMG'
import Navbar from '../components/Navbar'
import RestContainer from '../components/RestaurantsInHome/RestContainer'
import Signature from '../components/Signature'
import ChefContainer from '../components/ChefsInHome/chefContainer'
import ChefResContainer from '../components/ChefsRestaurantsInHome/chefsResContainer'
import Footer from '../components/Footer'
import { HomeStyle } from '../Style/HomeStyle'

const Home = () => {
  return (
    <HomeStyle>
      <Heroimg/>
      <RestContainer/>
      <DishContainer/>
      <Signature/>
      <ChefContainer/>
      <ChefResContainer/>
      <Footer/>
    </HomeStyle>
  )
}

export default Home