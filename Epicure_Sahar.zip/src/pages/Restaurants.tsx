import DishContainer from '../components/DishsInHome/DishContainer'
import Heroimg from '../components/HeroIMG'
import Navbar from '../components/Navbar'
import RestContainer from '../components/RestaurantsInHome/RestContainer'
import Signature from '../components/Signature'
import ChefContainer from '../components/ChefsInHome/chefContainer'
import RestPageContainer from '../components/ResPageContainer'
import MutalFooter from '../components/MutalFooter'

const Restaurants = () => {
  return (
    <div>
      
      <RestPageContainer/>
      {/* <MutalFooter/> */}
    </div>
  )
}

export default Restaurants