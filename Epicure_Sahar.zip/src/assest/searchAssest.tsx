import { useState } from "react";
import { ReactComponent as Hide} from '../Media/Icons/close_icon.svg'
import Search from "../PopUps/search";
import { Closeicon, SearchAssestStyle, Searchelements, SearchIcon, SearchTitle } from "../Style/SearchStyle";

const SearchAssest=()=>{

    const [showsearch, setshowsearch] = useState(false);
    const [showclose,setshowclose]= useState(false)
    const [visib,setvisib]= useState(true);
   

    const handleshowsearch = () => {
      setshowsearch(!showsearch);
      setshowclose(!showclose)
      setvisib(!visib);
      const b=document.getElementById('searchICN');
      if(b){
        if(!visib){
          b.style.visibility='hidden';
        }
        if(visib){
          b.style.visibility='visible';
        }
        }
      
  };
   
        return(
            <SearchAssestStyle>    
                <SearchIcon>
                    <img src={require('../Media/Icons/search_icon.png')} onClick={handleshowsearch} />
                </SearchIcon>    

                {showsearch ? <Searchelements>    
                    <Closeicon className="closeicon"  onClick={handleshowsearch} >
                      {showclose ?<Closeicon>
                       <Hide/>
                      </Closeicon>:null}
                   </Closeicon>    
                    <SearchTitle> 
                        Search
                    </SearchTitle>
                        <Search/>
                </Searchelements>:null}
            </SearchAssestStyle> 
        )


}

export default SearchAssest