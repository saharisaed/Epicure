import { useState } from "react";
import { Icon, Navbarelements } from "../Style/NavbarStyle";
import CartAssest from "./Cartassest";
import SearchAssest from "./searchAssest";

const Assest=() =>{
    const [showbag, setshowBag] = useState(false);
   
      const handleshowcart = () => {
          setshowBag(!showbag);
      
      };
  
    return(
        <Icon>
        {  
        <Navbarelements>
          <SearchAssest/>
          <Icon><img src={require('../Media/Icons/person_icon.png')} /></Icon>
          <CartAssest/>
        </Navbarelements>
        } 
        
      </Icon>
      
    )

}









export default Assest