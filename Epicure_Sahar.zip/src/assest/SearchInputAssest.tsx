import {createContext} from 'react';

const  res={
    name:'',
    chef:'',
    img:''
}
export default createContext({
    filteredrestaurant: res
});
