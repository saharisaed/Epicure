import { useState } from "react";
import Bag from '../PopUps/cart'
import { Cartassest, Cartelement, Carticon } from "../Style/CartStyle";

const CartAssest=()=>{
    const [showbag, setshowBag] = useState(false);
 
    const handleshowcart = () => {
        setshowBag(!showbag);
    };

    return(
        <Cartassest>
            <Carticon>
            <img src={require('../Media/Icons/cart_icon.png')} onClick={handleshowcart} />  
            </Carticon>
            {showbag ? <Cartelement>        
                <Bag/>
            </Cartelement>:null}
        </Cartassest>

    )


}

export default CartAssest